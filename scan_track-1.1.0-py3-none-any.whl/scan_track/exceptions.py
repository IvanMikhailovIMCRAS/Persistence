

class OutBoxError(Exception):
    def __str__(self):
        return "Some bead occure out of box > 1.5 box"
