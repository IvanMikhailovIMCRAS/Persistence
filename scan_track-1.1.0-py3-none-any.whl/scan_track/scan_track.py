import os
import warnings
from typing import List, Tuple

import numpy as np
from scan_track.periodic_box import Box

Bondtype = List[Tuple[int, int]]


class ReadTrack():
    """
    This class is used for TRACK file scanning

    Atributes:
        self.path (str): path to TRACK file
        self.time_step (int): number of the current step
        self.file_track (file): link to TRACK file
        self.num_atoms (int): number of beads in the system
        self.box (Box): 3D-box for simulation of a molecular system
        self.x, self.y, self.z (np.ndarray): coordinates of the current step
        self.btype (np.ndarray): array of bead types    
    """

    def __init__(self, path: str = '') -> None:
        """
        Args:
            path (str, optional): path to TRACK file. Defaults to ''.

        Raises:
            FileNotFoundError: TRACK is not found
        """
        self.path: str = os.path.join(path, 'TRACK')
        self.time_step: int = 0
        try:
            self.file_track = open(self.path, 'r')
        except:
            raise FileNotFoundError(f'{str(self.path)} is not found')
        try:
            title = self.file_track.readline().split()
            self.num_atoms = int(title[1])
            self.box = Box(float(title[3]), float(title[4]), float(title[5]))
        except:
            self.file_track.close()
            raise FileNotFoundError(f'{str(self.path)} is not correct')
        self.x = np.zeros(self.num_atoms, dtype=float)
        self.y = np.zeros(self.num_atoms, dtype=float)
        self.z = np.zeros(self.num_atoms, dtype=float)
        self.btype = np.zeros(self.num_atoms, dtype=int)
        self.__iterator = list(range(self.num_atoms))

    def one_step(self) -> bool:
        """
        Scans one step from TRACK

        Returns:
            bool: True if successful, false otherwise 
        """
        try:
            title = self.file_track.readline().split()
            self.time_step = int(title[1])
            for i in self.__iterator:
                record = self.file_track.readline().split()
                self.x[i] = float(record[1])
                self.y[i] = float(record[2])
                self.z[i] = float(record[3])
                self.btype[i] = int(record[4])
            return True
        except:
            self.file_track.close()
            return False

    def __str__(self):
        return f"""
                numbeads:{self.num_atoms}
                path:{self.path}
                """


def read_bonds(path: str) -> Bondtype:
    path = os.path.join(path, 'BONDS')
    bonds: Bondtype = [(0, 0)]
    try:
        file_bonds = open(path, 'r')
        title = file_bonds.readline().split()
        num_bonds = int(title[1])
        for _ in range(num_bonds):
            t = tuple(map(int, file_bonds.readline().split()))
            if len(t) == 2:
                bonds.append((t[0], t[1]))
            else:
                raise FileNotFoundError(f'{str(path)} is not correct')
        print(bonds)
        file_bonds.close()
    except:
        warnings.warn('BONDS file was not used successfully')
    return bonds
